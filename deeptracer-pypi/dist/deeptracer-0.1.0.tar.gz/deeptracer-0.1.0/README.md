# DeepTracer

DeepTracer is a Python package for detecting deepfake content in images and videos using a pretrained model.

## Installation

To install DeepTracer, you can clone the repository and run:

```bash
pip install deeptracer

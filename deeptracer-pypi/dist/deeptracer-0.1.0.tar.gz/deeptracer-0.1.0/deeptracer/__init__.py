# deeptracer/__init__.py

from .model import DeepFakeDetector

__all__ = ['DeepFakeDetector']  # This ensures both classes are accessible
